
/**
 * Write a description of class Macburger here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Macburger
{
    //fields
    private int reference;
    private String location;
    private int maxseatcapacity;
    private int eaters;
    private boolean disabledaccess;
    
    //constructors
    public Macburger(int refNo, String loc, int maxCap)
    {
        reference = refNo;
        location = loc;
        maxseatcapacity = maxCap;
        eaters = 0;
        disabledaccess = false;
    }
    
    //methods
    //accessors
    
    public String getLocation()
    {
        return location;
    }
    
    public String isFull()
    {
        if(eaters == maxseatcapacity)
        {
            return "Macburger is currently full";
        }
        else
        {
            return "Not Full";
        }
    }
    
    public String toString()
    {
        String ss = "\nReference number: " + reference + 
        "\nLocation: " + location + 
        "\nMax capacity: " + maxseatcapacity + 
        "\nCurrent capacity: " + eaters +
        "\nDisabled access: " + disabledaccess;
        return ss;
    }
    
    //mutators
    
    public void addCustomers(int amount)
    {
        eaters = eaters + amount;
    }
    
    public void customersLeave(int no)
    {
        if(eaters >= no)
        {
            eaters = eaters - no;
        }
    }
}
