 
/**
 * A Permit has an id number, name, a luxury rating and number of credits.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Permit 
{
    //fields
    private int permitID;
    private String guestname;
    private int luxuryrating;
    private int credits;
    
    //constructors
    public Permit(int ID, String nme, int rating, int cred)
    {
        permitID = ID;
        guestname = nme;
        luxuryrating = rating;
        credits = cred;
    }
    
    // methods
    //accessors
    public String getName() // returns the guest name
    {
        return guestname;
    }
    
    public int getPermitId() //returns permitID value
    {
        return permitID;
    }
    
    public int getluxuryrating() //returns luxury rating value
    {
        return luxuryrating;
    }
    
    public int getcredits() //returns credits value
    {
        return credits;
    }
    
    public String toString() //returns info about the passenger
    {
        String ss = "\nGuest name: " + guestname + 
        "\nPermitID: " + permitID + 
        "\nRating: " + luxuryrating + 
        "\nCredits: " + credits + "\n";
        return ss;
    }
    
    public boolean checkcred() //check if a passenger has enough credits for a journey
    {
        if(credits >= 3)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    //mutators
    public void addCred(int amount) //adds credits
    {
        credits = amount + credits;
    }
    
    public void minusCred(int amount) //deducts credits
    {
        if(credits >= amount)
        {
            credits = credits - amount;
        }
    }
}

