 
/**
 * A shuttle provides a one-way connection between two planets. It
 * has a Shuttle code and information about both the source and
 * the destination planet
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Shuttle
{
    //fields
    private String journeycode;
    private Planet fromplanet;
    private Planet toplanet;
    
    //constructors
    public Shuttle(String jnrcode, Planet fromplan, Planet toplan)
    {
        journeycode = jnrcode;
        fromplanet = fromplan;
        toplanet = toplan;
    }
    
    //accessors
    public String getJourneyCode() // returns journey code
    {
        return journeycode;
    }
    
    public boolean cantravel(Permit ps) // checks if passgenger hass enough credits to travel
    {
        int permID = ps.getPermitId();
        double permitcred = ps.getcredits();
        permitcred -= 3;
        
        if ((ps.getluxuryrating() >= toplanet.getRating()) && !toplanet.isFull() 
        && (permitcred >= 0) && fromplanet.isWithPermit(permID))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public String transferpassenger(Permit ps) // processes the travel
    {
        int permID = ps.getPermitId();
        double permitcred = ps.getcredits();
        permitcred -= 3;
        
        if(ps.getluxuryrating() < toplanet.getRating())
        {
            return "Luxury rating of permit not sufficient for travel - Passenger not transferred"; 
        }
        else if(toplanet.isFull())
        {
            return "Destination planet is currently full - Passenger not transferred";
        }
        else if(permitcred < 0)
        {
            return "Insufficient credits - Passenger not transferred";
        }
        else if(!fromplanet.isWithPermit(permID))
        {
            return "Permit not listed in the source planet - Passenger not transferred";
        }
        else if (cantravel(ps))
        {
            ps.minusCred(-3);
            toplanet.enter(ps);
            fromplanet.leave(ps);
            return "Passenger " + permID + "has travelled to " + toplanet.getName();
        }
        else{
            return "unable to move passenger"; 
        }
    }
    
    public String toString() // displays details of the journey
    {
        return "\nJourney code : " + journeycode +
        "\nFrom : " + fromplanet.getPlanetNum() + 
        "Name: " + fromplanet.getName() +
        "\nTo : " + toplanet.getPlanetNum() + 
        "Name: " + toplanet.getName();
    }
    
    //mutators
    public void changejourney(String jnry) //this is subject to further changes
    {
        journeycode = jnry;
    }
}
