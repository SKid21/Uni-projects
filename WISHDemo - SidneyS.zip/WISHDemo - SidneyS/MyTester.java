 
import java.util.*;
/**
 * Write a description of class OTester here.
 * 
 * @author 
 * @version  
 */
public class MyTester 
{   

    public static void main(String[] args)
    {
        Resort wayward = new Resort("Wayward Asteroids");
    
        // write your tests here by invoking Resort methods on the Resort object called wayward
        
        //Displaying all permits in each planet
        System.out.print("********Showing permits in each planet.******");
        System.out.println(wayward.getAllPermitsOnEachPlanet());
        
        //can travel tests
        System.out.println("\n*******Checking whether passengers can travel******");
        System.out.println("Can permit 1000 - 1003 go from Home to Sprite: expect true for all");
        System.out.println("1. Can 1000 travel from Home to Sprite: " + wayward.canTravel(1000,"ABC1"));
        System.out.println("2. Can 1001 travel from Home to Sprite: " + wayward.canTravel(1001,"ABC1"));
        System.out.println("3. Can 1002 travel from Home to Sprite: " + wayward.canTravel(1003,"ABC1"));
        
        
        //some transfers
        System.out.println("\n**** Making some shuttle journeys ******");
        System.out.println("\n1. 1000 travels from Home to Sprite: expect confirmation message below");
        String jnr1 = wayward.travel(1000, "ABC1");
        System.out.println(jnr1);
        System.out.println("\n2. 1001 travels from Home to Sprite: expect confirmation message below");
        String jnr2 = wayward.travel(1001, "ABC1");
        System.out.println(jnr2);
        System.out.println("\n3. 1002 travels from Solo to Sprite: expect rejection message below");
        String jnr3 = wayward.travel(1002, "HJK7");
        System.out.println(jnr3);
        System.out.println("\n4. 1001 travels from Sprite to Solo: expect confirmation message below");
        String jnr4 = wayward.travel(1001, "GHJ6");
        System.out.println(jnr4);
        
        //show all permits in Solo
        System.out.println("\n***** Showing all permits in Solo *****");
        String solo = wayward.getAllPermitsOnOnePlanet("Solo");
        System.out.println(solo);
        
        
        //Finding a permit's current location
        System.out.println("\n**** Finding Permit 1000's curent location: expect Sprite");
        System.out.println("Current location: " + wayward.getPermitLocation(1000));
        
        
        //shows the specific details of a permit
        System.out.println("\n**** Finding Permit 1003's specific details.");
        String ddd = wayward.getPermitDetails(1003);
        System.out.println(ddd);
        
        //get planet number test
        System.out.println("\n**** Finding the planet number of Fantasia: expect 3");
        System.out.println("Planet No: " + wayward.getPlanetNumber("Fantasia"));
        
        //demonstrating additional functionality - task 7
        //displays the rich guests
        System.out.println("\n**** Displaying the rich guests: expect Nils, Raj, Sol and Tel.");
        String ggg = wayward.getRichGuests();
        System.out.println(ggg);
        

        //moves a permit to the home world - displays the permit details with the changes
        System.out.println("\n**** Moving a permit to the home world");
        Permit p = wayward.getPermit(1001);
        String s = p.toString() + "\nCurrent Location: " + 
                wayward.getPermitLocation(1001);
        wayward.moveHome(1001);
        s += "\nMoved to: " + 
                wayward.getPermitLocation(1001);
        System.out.println(s);
        
        
        //evacuating all permits to the home planet
        System.out.println("\n**** Moving all permits to the home planet");
        String n = "Expect permits 1000 - 1008 at home planet.\n" + wayward.getAllPermitsOnOnePlanet("Home");
        System.out.println(n);
    }
}
