
/**
 * Write a description of class DoCPermitTest here.
 *
 * @author (Sidney Ssozi)
 * @version (a version number or a date)
 */
public class DoCPermitTest
{
    public static void main(String[] args)
    {
        //task 2.1
        Permit guest1 = new Permit(4567, "Mary", -2, 17);
        
        //task 2.2
        System.out.println("\n************Deduct credit test**********");
        guest1.minusCred(5);
        System.out.println("\nName: "+ guest1.getName() );
        System.out.println("\nNew credits: "+ guest1.getcredits() +" 'expect 5 credits deducted'");
        
        System.out.println("\n************Permit details**********");
        System.out.println("\nGuest 1" + guest1.toString());
        
        System.out.println("\n************Display rating test**********");
        System.out.println("\nRating: "+ guest1.getluxuryrating());
    }
}
