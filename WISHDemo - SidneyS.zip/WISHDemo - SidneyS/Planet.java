import java.util.*;
/**
 * An planet is part of a STAR resort.Each planet has a name,  a luxury rating
 * and a capacity which represents the maximum number of people(permits) who can be on the  
 * planet at any one time. Each planet must maintain a list of all people (permits)
 * currently on the planet. These lists are updated whenever permits enter or leave 
 * an planet,so that it is always possible to say how many people (permits) are on the planet 
 * and who they are.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class Planet
{
    //fields
    private int planetNumber, luxuryRating, maxCapacity;
    private String name;
    
    private ArrayList<Permit> permitList;
    
    //constructor
    public Planet(int planNum, String nme, int rate, int max)
    {
        planetNumber = planNum;
        name = nme;
        luxuryRating = rate;
        maxCapacity = max;
        permitList = new ArrayList<Permit>();
    }
    
    //methods
    //accessors
    public int getPlanetNum() //returns the planet number
    {
        return planetNumber;
    }
    
    public String getName() //returns the planet name
    {
        return name;  
    }
    
    public int getRating() //returns the luxury rating of the planet
    {
        return luxuryRating;
    }
    
        public String getPermitList() //Lists all the permits currently on the planet
    {
        String ss = "";
        if (permitList.size() > 0)
        {
            for(Permit temp: permitList)
            {
                ss = ss + temp.toString();
            }
            return ss + "\n*******************************";
        }
        return "\nNo permits" + "\n*******************************" ;
    }
    
    public String getPermitDet(int pID) //Returns the details of a specific permit on the planet
    {
        for(Permit temp: permitList)
        {
            if(temp.getPermitId() == pID)
        {
            return temp.toString();
        }
        }
    return "Permit not found";
    }
    
    public String toString() //Displays planet details and a list of the Permits
    {
        return ("\nPlanet name: " + name + 
                "\nPlanet number: " + planetNumber + 
                "\nLuxury Rating: " + luxuryRating + 
                "\n\n****Permit List*****" + getPermitList() + "\n");
    }
    
    public boolean isFull() //checks if permitList has reached maximum capacity
    {
        return permitList.size() >= maxCapacity;
    }
    
    public boolean isWithPermit(int pID) //Checks if the planet has the specified permit
    {
        for (int i = 0; i < permitList.size(); i++)
        {
            Permit temp = permitList.get(i);
            if(temp.getPermitId() == pID)
            {
                return true;
            }
        }
        return false;
    }
    
    //mutators
    public void enter(Permit p) //Adds a permit
    {
        permitList.add(p); 
    }
    
    public void leave(Permit p) //Removes a permit
    {
        permitList.remove(p);
    }
}