
/**
 * Write a description of class PermitTester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class PermitTester
{
   public static void main(String[] args)
   {
       //declare and creates 3 permits
       Permit guest1 = new Permit(1000, "Lynn", 5, 1);
       Permit guest2 = new Permit(1001, "May", 3, 20);
       Permit guest3 = new Permit(1002, "Nils", 10, 20);
       
       //call the different methods
       //guest1 methods - accessors
       System.out.println("Name: "+ guest1.getName());
       System.out.println("ID: "+ guest1.getPermitId());
       System.out.println("Rating: "+ guest1.getluxuryrating());
       System.out.println("Credits: "+ guest1.getcredits());
       System.out.println("Valid: "+ guest1.checkcred());
       //guest2 methods - accessors
       System.out.println("\nName: "+ guest2.getName());
       System.out.println("ID: "+ guest2.getPermitId());
       System.out.println("Rating: "+ guest2.getluxuryrating());
       System.out.println("Credits: "+ guest2.getcredits());
       System.out.println("Valid: "+ guest2.checkcred());
       //guest3 methods - accessors
       System.out.println("\nName: "+ guest3.getName());
       System.out.println("ID: "+ guest3.getPermitId());
       System.out.println("Rating: "+ guest3.getluxuryrating());
       System.out.println("Credits: "+ guest3.getcredits());
       System.out.println("Valid: "+ guest3.checkcred());
       
       //tostring test
       System.out.println("\n************toString() test************");
       System.out.println("\nGuest 3" + guest3.toString());
       
       
       //mutators
       //add credits
       guest1.addCred(20);
       guest2.addCred(20);
       guest3.addCred(20);
       //display changes
       System.out.println("\n************Add credit test**********");
       System.out.println("Name: "+ guest1.getName());
       System.out.println("New credits: "+ guest1.getcredits() +" 'expect 20 credits added'");
       System.out.println("\nName: "+ guest2.getName());
       System.out.println("New credits: "+ guest2.getcredits() +" 'expect 20 credits added'");
       System.out.println("\nName: "+ guest3.getName());
       System.out.println("New credits: "+ guest3.getcredits() +" 'expect 20 credits added'");
       //deduct credits
       guest1.minusCred(30);
       guest2.minusCred(30);
       guest3.minusCred(30);
       //display changes
       System.out.println("\n************Deduct credit test**********");
       System.out.println("Name: "+ guest1.getName() );
       System.out.println("New credits: "+ guest1.getcredits() +" 'expect nothing to be deducted'");
       System.out.println("\nName: "+ guest2.getName());
       System.out.println("New credits: "+ guest2.getcredits() +" 'expect 30 credits deducted'");
       System.out.println("\nName: "+ guest3.getName());
       System.out.println("New credits: "+ guest3.getcredits() +" 'expect 30 credits deducted'");
   }
}
