
/**
 * Write a description of class DemoC here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class DemoC
{
    public static void main(String[] args)
    {
        Resort trojans = new Resort("Trojans");
        
        //Displaying all permits in each planet task 3.2
        System.out.print("********Showing permits in each planet.******");
        System.out.println(trojans.getAllPermitsOnEachPlanet());
        
        //travel requests task 3.3
        System.out.print("******\nTravel requests******");
        System.out.println("\n1. 1004 travels from Home to Sprite: expect confirmation message below");
        String jnr1 = trojans.travel(1004, "ABC1");
        System.out.println(jnr1);
        System.out.println("\n2. 1006 travels from Home to Sprite: expect confirmation message below");
        String jnr2 = trojans.travel(1006, "ABC1");
        System.out.println(jnr2);
        System.out.println("\n3. 1007 travels from Solo to Sprite: expect rejection message below");
        String jnr3 = trojans.travel(1007, "HJK7");
        System.out.println(jnr3);
        System.out.println("\n4. 1004 travels from Sprite to Tropicana: expect confirmation message below");
        String jnr4 = trojans.travel(1004, "CDE3");
        System.out.println(jnr4);
        System.out.println("\n5. 1007 travels from Sprite to Fantasia: expect confirmation message below");
        String jnr5 = trojans.travel(1007, "EFGH");
        System.out.println(jnr5);
        System.out.println("\n6. 1003 travels from Home to Sprite: expect confirmation message below");
        String jnr6 = trojans.travel(1003, "ABC1");
        System.out.println(jnr6);
        System.out.println("\n7. 1003 travels from Sprite to Solo: expect confirmation message below");
        String jnr7 = trojans.travel(1003, "GHJ6");
        System.out.println(jnr7);
        System.out.println("\n8. 1006 travels from Sprite to Tropicana: expect confirmation message below");
        String jnr8 = trojans.travel(1006, "GHJ6");
        System.out.println(jnr8);
        
        //task 3.4
        System.out.print("*******\nShow permits' current locations******");
        System.out.println(trojans.getAllPermitsOnEachPlanet());
        
        System.out.println("\n**** Finding Permit 1004's curent location: expect Sprite");
        System.out.println("\nCurrent location: " + trojans.getPermitLocation(1004));
        
        System.out.println("\n**** Finding out if 1003 can travel");
        System.out.println("\n1. Can 1000 travel from Sprite to Home: " + trojans.canTravel(1003,"BCD2"));
        
        
        
        
        
        
        
        
        
    }
}
