 

import java.util.*;

/**This class implements the WISH interface
 *
 * @author 
 * @version 
 **/
public class Resort implements WISH
{
    private String location; 
    private ArrayList<Permit> allPermits = new ArrayList<Permit>();
    private ArrayList<Planet> allPlanets = new ArrayList<Planet>(); 
    private ArrayList<Shuttle> allShuttles = new ArrayList<Shuttle>(); 
    
    /** constructor
     */
    public Resort(String loc) 
    {
        location = loc;
        loadPlanets();
        loadPermits();
        setUpShuttles();
    }
    
    /**
     * Returns all of the details of all planets including the permits
     * currently on each planet, on "No permits"
     * @return all of the details of all planets including location 
     * and all permits currently on each planet, or "No permits" 
     */
    public String toString()
    {
        String ss = location + ": ";
        for(Planet temp: allPlanets)
        {
            ss += temp.toString();
        }
        return ss;
    }
    
    /**Returns a String with details of a permit
     * @param permitId - id number of the permit
     * @return the details of the permit as a String, or "No such permit"
     */
    public String getPermitDetails(int permitId)
    {
        Permit pp = getPermit(permitId);
        if (pp != null){
            return pp.toString();
        }
        return "No such permit";
    }

    
    /** Given the name of a planet, returns the planet id number
     * or -1 if planet does not exist
     * @param name of planet
     * @return id number of planet
     */
    public int getPlanetNumber(String ww)
    {
        Planet pp = getPlanet(ww);
        if (pp != null)
        {
            return pp.getPlanetNum();
        }
        return -1;
    }
    
    /**Returns a String representation of all the permits on all planets
     * @return a String representation of all permits on all planets
     **/
    public String getAllPermitsOnEachPlanet()
    {
        String ss = "";
        for(Planet temp: allPlanets)
        {
            ss += temp.getName() + " {" + temp.getPermitList() + "} ";
        }
        return ss;
    } 
 
    
    /**Returns the name of the planet which contains the specified permit or null
     * @param tr - the specified permit
     * @return the name of the Planet which contains the permit, or null
     **/
    public String getPermitLocation(int tr)
    {
        for(Planet temp: allPlanets)
        {
            if(temp.isWithPermit(tr))
            {
                return temp.getName();
            }
        }
        return null;
    }
    
               
    /**Returns a String representation of all the permits on specified planet
     * @return a String representation of all permits on specified planet
     **/
    public String getAllPermitsOnOnePlanet(String planet)
    {
        String ss = "";
        Planet pp = getPlanet(planet);
        ss += pp.getName() + " {" + pp.getPermitList() + "} ";;
        return ss;
    }   

    /**Returns a String representation of all the permits with a luxury rating greater than 5
     * @return a String representation of all permits with luxury rating > 5
     **/
    public String getRichGuests()
    {
        String n = "";
        for(Permit temp: allPermits)
        {
            if(temp.getluxuryrating() > 5)
            {
                n += " {" + temp.toString() + "} ";
            }
        }
        return n;
    } 
    
    /** Removes a permit from its current planet directly to the 'Home' world
     * @remove a permit from one planet to the 'Home' planet
     **/
    public void moveHome(int Id)
    {
        Planet home = allPlanets.get(0);
        Permit p = getPermit(Id);
        String curs = getPermitLocation(Id);
        Planet curr = getPlanet(curs);
        curr.leave(p);
        home.enter(p);
    }
    
    /** Removes all permits on the current planet directly to the 'Home' world
     * @remove all permits directly to the 'Home' world
     **/    
    public void evacuateAll()
    {
        Planet home = allPlanets.get(0);
        for(Planet temp : allPlanets)
        {
            if(temp != allPlanets.get(0))
            {
                for(Permit temp1 : allPermits)
                {
                    temp.leave(temp1);
                    home.enter(temp1);
                }
            }
        }
    }
    
     /**Returns true if a Permit is allowed to move using the shuttle, false otherwise
      * A move can be made if:  
      * the rating of the permit  >= the rating of the destination planet
      * AND the destination planet is not full
      * AND the permit has sufficient credits
      * AND the permit is currently on the source planet
      * AND the permit id is for a permit on the system
      * AND the shuttle code is the code for a shuttle on the system
      * @param pId is the id of the permit requesting the move
      * @param shtlCode is the code of the shuttle journey by which the permit wants to pPermitel
      * @return true if the permit is allowed on the shuttle journey, false otherwise 
      **/
    public boolean canTravel(int trId, String shtlCode)
    {
        Permit p = getPermit(trId); // Resort method - see below
        Shuttle s = getShuttle(shtlCode);  // Resort method - see below
        
        if (p == null || s == null)    // permit or shuttle not found
        {
            return false;
        }
        else    // permit && shuttle found
        {
            return s.cantravel(p);
        }
    }   

    
    /**Returns the result of a permit requesting to move by Shuttle.
     * A move will be successful if:  
     * the luxury rating of the permit  >= the luxury rating of the destination planet
     * AND the destination planet is not full
     * AND the permit has sufficient credits
     * AND the permit is currently on the source planet
     * AND the permit id is for a permit on the system
     * AND the shuttle code is the code for a shuttle on the system
     * If the shuttle journey can be made, the permit information is removed from the source
     * planet, added to the destination planet and a suitable message returned.
     * If shuttle journey cannot be made, the state of the system remains unchanged
     * and a message specifying the reason is returned.
     * @param ppId is the id of the permit requesting the move
     * @param shtlCode is the code of the shuttle journey by which the permit wants to pPermitel
     * @return a String giving the result of the request 
     **/
    public String travel(int permitId, String shtlCode )
    {   //other checks optional
        Permit p = getPermit(permitId); // Resort method - see below
        Shuttle s = getShuttle(shtlCode);  // Resort method - see below
        
        if ( p == null || s == null) // permit or shuttle not found
        {
            return "no such permit";
        }
        else if (s == null)
        {
            return "no such shuttle";
        }
        else   // permit and shuttle found
        {
            if (canTravel(permitId, shtlCode))
            {
                s.transferpassenger(p); //Shuttle method
                return "All conditions are met, "+ p.getPermitId() +" has been transferred";
            }
            else
            {
                return s.transferpassenger(p);
            }
        }
    } 
         
    // These methods are for Task 6 only and not required for the Demonstration 
    // If you choose to implement them, uncomment the following code
    

    /** Allows a permit to top up their credits.This method is not concerned with 
     *  the cost of a credit as currency and prices may vary between resorts.
     *  @param id the id of the permit toping up their credits
     *  @param creds the number of credits purchased to be added to permits information
     */
    public void topUpCredits(int id, int creds)
    {
        Permit p = getPermit(id);
        p.addCred(creds);
    }
   
    //***************private methods**************
    private void loadPlanets()
    {
        allPlanets.add(new Planet(0, "Home", 0, 1000));
        allPlanets.add(new Planet(1, "Sprite", 1, 100));
        allPlanets.add(new Planet(2, "Tropicana", 3, 10));
        allPlanets.add(new Planet(3, "Fantasia", 5, 2));
        allPlanets.add(new Planet(4, "Solo", 1, 1));
        allPlanets.add(new Planet(5, "Squash", 5, 6)); //demo task 4.2
    }
    
    private void setUpShuttles()
    {
        // find planets in allPlanets arrayList
        Planet p0 = getPlanet("Home");   //Resort method
        Planet p1 = getPlanet("Sprite");
        Planet p2 = getPlanet("Tropicana");
        Planet p3 = getPlanet("Fantasia");
        Planet p4 = getPlanet("Solo");
        Planet p5 = getPlanet("Squash"); //demo task 4.2
        
        //just some Shuttles listed  
        allShuttles.add(new Shuttle("ABC1",p0,p1)); //Home to Sprite
        allShuttles.add(new Shuttle("BCD2",p1,p0)); //Sprite to Home
        allShuttles.add(new Shuttle("CDE3",p1,p2)); //Sprite to Tropicana
        allShuttles.add(new Shuttle("DEF4",p2,p1)); //Tropicana to Sprite
        allShuttles.add(new Shuttle("EFG5",p3,p1)); //Fantasia to Sprite
        allShuttles.add(new Shuttle("GHJ6",p1,p4)); //Sprite to Solo 
        allShuttles.add(new Shuttle("HJK7",p4,p1)); //Solo to Sprite 
        allShuttles.add(new Shuttle("JKL8",p2,p3)); //Tropicana to Fantasia
        allShuttles.add(new Shuttle("FFF",p5,p2)); //Squash to Tropicana (demo task 4.3)
        allShuttles.add(new Shuttle("GGG",p1,p5)); //Sprite to Squash (demo task 4.3)
    }
    
    private void loadPermits()
    {
        Planet home = allPlanets.get(0);
        allPermits.add(new Permit(1000, "Lynn", 5, 10));
        allPermits.add(new Permit(1001, "May", 3, 20));
        allPermits.add(new Permit(1002, "Nils", 10, 20));
        allPermits.add(new Permit(1003, "Olek", 2, 12));
        allPermits.add(new Permit(1004, "Pan", 3, 3));
        allPermits.add(new Permit(1005, "Quin", 1, 5));
        allPermits.add(new Permit(1006, "Raj", 10, 6));
        allPermits.add(new Permit(1007, "Sol", 7, 20));
        allPermits.add(new Permit(1008, "Tel", 6, 24));
        allPermits.add(new Permit(1111, "Val", 3, 15)); //demo task 4.1
        
        for(Permit temp : allPermits)
        {
            home.enter(temp);
        }    
    }
 
    /** Returns the permit with the permit id specified by the parameter
     * @return the permit with the specified name
     **/
    public Permit getPermit(int id)
    {
        for(int i = 0; i < allPermits.size(); i++)
        {
            Permit temp = allPermits.get(i);  // call ArrayList method
            if(temp.getPermitId() == id)      // call Permit method
            {
                return temp;
            }
        }
        return null;
    }
    
    
    /** Returns the planet with the name specified by the parameter
     * @return the planet with the specified name
     **/
    private Planet getPlanet(String planetName)
    {
        for(Planet temp : allPlanets)
        {
            System.out.println(temp.toString());
            String c = temp.getName();
            if(c.equals(planetName))
            {
                System.out.println("Found");
                return temp;
            }
            else
            {
                System.out.println("Not found");
            }
        }
        return null;
    }
    
    /** Returns the planet with the name specified by the parameter
     * @return the planet with the specified name
     **/
    private Shuttle getShuttle(String shut)
    {
        for(Shuttle temp : allShuttles)
        {
            System.out.println(temp.toString());
            String c = temp.getJourneyCode();
            if(c.equals(shut))
            {
                System.out.println("Found");
                return temp;
            }
            else
            {
                System.out.println("Not found");
            }
        }
        return null;
    }
    
    /** Demo task 5
     * This takes an ID, finds the permit with that id and returns the credits.
     */
    public String showPermitCredits(int id)
    {
        String p = " ";
        for(int i = 0; i < allPermits.size(); i++)
        {
            Permit temp = allPermits.get(i);  // call ArrayList method
            if(temp.getPermitId() == id)      // call Permit method
            {
               p += "Credits: " + temp.getcredits();
               return p;
            }
        }
        return "-1";
    }
}